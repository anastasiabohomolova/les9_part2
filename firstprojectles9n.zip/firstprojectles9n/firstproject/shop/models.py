from django.db import models

# Create your models here.
def type():
    category = [
        ('dresses', 'сукні'),
        ('suits', 'костюми'),
        ('bags', 'сумки')
    ]
    return category
class Shoping(models.Model):
    name = models.TextField(max_length=15)
    file = models.ImageField()
    price = models.CharField(max_length=10)
    way = models.URLField()
    type = models.CharField(max_length=10, choices=type(), default='')

    def __str__(self):
        return self.name

    def get_detail_url(self):
        return f'/shop/detail/{self.id}'

    def get_url_category(self):
        return 'f/shop/category'








